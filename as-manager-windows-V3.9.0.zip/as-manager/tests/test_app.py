from datetime import date
from unittest.mock import patch
from contextlib import nullcontext
from types import SimpleNamespace
import copy
import importlib.util
import io
import json
import os
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from xml.etree import ElementTree as ET



def excel_text(cell, namespaces):
    value = cell.find('s:is/s:t', namespaces)
    if value is None:
        value = cell.find('s:v', namespaces)
    return value.text if value is not None else None


class Workflow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.previous_data = os.environ.get('AS_DATA_DIR')
        os.environ['AS_DATA_DIR'] = cls.tmp.name
        spec = importlib.util.spec_from_file_location('app', Path(__file__).resolve().parents[1] / 'app.py')
        cls.app = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.app)
        cls.server = cls.app.ThreadingHTTPServer(('127.0.0.1', 0), cls.app.Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = 'http://127.0.0.1:' + str(cls.server.server_port)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.tmp.cleanup()
        if cls.previous_data is None:
            os.environ.pop('AS_DATA_DIR', None)
        else:
            os.environ['AS_DATA_DIR'] = cls.previous_data

    def setUp(self):
        with self.app.db() as c:
            for table in ('slips', 'settings', 'suppliers', 'products', 'receipt_options', 'app_meta'):
                c.execute('DELETE FROM ' + table)
        self.post('/api/suppliers', {'name': '공급사 A', 'phone': '02-123-4567'})
        for name in ('메모리 DDR5', '그래픽카드', '메인보드'):
            self.post('/api/products', {'name': name})

    def req(self, path, data=None):
        request = urllib.request.Request(self.base + path, data=json.dumps(data).encode() if data is not None else None,
                                         headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(request) as r:
            return r.read()

    def post(self, path, data):
        return json.loads(self.req(path, data))

    def get(self, path):
        return json.loads(self.req(path))

    def create(self, date='2026-10-19'):
        return self.post('/api/slips', {
            'date': date, 'supplier': '공급사 A', 'company': '테스트 업체', 'kind': 'AS 발송', 'status': '발송',
            'items': [
                {'name': '메모리 DDR5', 'serial': '001234', 'qty': 2, 'fault': '부팅 불가'},
                {'name': '그래픽카드', 'qty': 1}, {'name': '메인보드', 'qty': 1}
            ]})

    def ret(self, s, **kwargs):
        return self.post('/api/returns', {'id': s['id'], 'version': s['version'], 'date': '2026-10-20', **kwargs})

    def assert_error(self, code, path, data):
        with self.assertRaises(urllib.error.HTTPError) as err:
            self.req(path, data)
        self.assertEqual(err.exception.code, code)

    def test_partial_return_then_all_remaining(self):
        s = self.create()
        s = self.ret(s, items=[{'index': 0, 'qty': 1}, {'index': 2, 'qty': 1}], result='교환')
        self.assertEqual(s['status'], '부분반환')
        self.assertEqual([i['remainingQty'] for i in s['items']], [1, 1, 0])
        s = self.ret(s, all=True, date='2026-10-21')
        self.assertEqual(s['status'], '반환완료')
        self.assertEqual(s['returned'], '2026-10-21')
        self.assertEqual([i['remainingQty'] for i in s['items']], [0, 0, 0])
        self.assertEqual(len(s['returns']), 2)
        self.assertEqual(s['returns'][0]['date'], '2026-10-20')
        self.assertEqual(s['returns'][1]['items'], [{'index': 0, 'qty': 1}, {'index': 1, 'qty': 1}])
        self.assertEqual(self.get('/api/slips')[0]['returns'], s['returns'])

    def test_one_click_full_return(self):
        s = self.ret(self.create(), all=True)
        self.assertEqual(s['status'], '반환완료')
        self.assertEqual(sum(i['returnedQty'] for i in s['items']), 4)

    def test_delete_active_partial_completed_slips_and_excel_exclusion(self):
        active = self.create()
        partial = self.ret(self.create(), items=[{'index':0,'qty':1}], mbRepairReport='부분 수리')
        complete = self.ret(self.create(), all=True, mbRepairReport='완료 수리')
        for slip in (active, partial, complete):
            self.assertEqual(self.post('/api/slips/delete', {'id':slip['id'],'version':slip['version']})['ok'], True)
            self.assertNotIn(slip['id'], [row['id'] for row in self.get('/api/slips')])
            with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
                self.assertNotIn(slip['number'], z.read('xl/worksheets/sheet1.xml').decode())
            self.assert_error(404, '/api/slips/delete', {'id':slip['id'],'version':slip['version']})
        self.assertEqual(self.get('/api/slips'), [])
        self.assertEqual(self.get('/api/suppliers')[0]['name'], '공급사 A')
        self.assertEqual(len(self.get('/api/products')), 3)
        self.assertEqual(self.create()['number'], '261019-04')

    def test_delete_checks_latest_version_and_valid_target(self):
        s = self.create()
        for request in ({}, {'id':s['id']}, {'id':True,'version':0}, {'id':str(s['id']),'version':0},
                        {'id':s['id'],'version':True}, {'id':s['id'],'version':-1}, {'id':0,'version':0}):
            self.assert_error(400, '/api/slips/delete', request)
        updated = self.ret(s,items=[{'index':0,'qty':1}])
        self.assert_error(409, '/api/slips/delete', {'id':s['id'],'version':s['version']})
        self.assertEqual(self.get('/api/slips')[0]['returns'], updated['returns'])
        self.assert_error(404, '/api/slips/delete', {'id':999999,'version':0})

    def test_concurrent_deletion_and_return_do_not_overwrite_each_other(self):
        s = self.create()
        def submit(path):
            try:
                self.post(path, {'id':s['id'],'version':s['version'],'date':'2026-10-20','all':True})
                return 200
            except urllib.error.HTTPError as e:
                return e.code
        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(submit, ['/api/slips/delete','/api/returns']))
        self.assertEqual(outcomes.count(200), 1)
        self.assertIn(next(code for code in outcomes if code != 200), (404,409))
        saved = self.get('/api/slips')
        if saved:
            self.assertEqual(saved[0]['status'], '반환완료')
            self.assertEqual(len(saved[0]['returns']), 1)

    def test_deletion_reserves_existing_numbers_without_sequence_metadata(self):
        s = self.create()
        with self.app.db() as c:
            c.execute("DELETE FROM app_meta WHERE key LIKE 'slip_number_max:%'")
        self.post('/api/slips/delete', {'id':s['id'],'version':s['version']})
        self.assertEqual(self.create()['number'], '261019-02')

    def test_invalid_returns_do_not_mutate_record(self):
        s = self.create()
        base = {'id': s['id'], 'version': s['version'], 'date': '2026-10-20'}
        for items in ([], [{'index': 0, 'qty': 3}], [{'index': 0, 'qty': 0}], [{'index': 0, 'qty': -1}],
                      [{'index': 0, 'qty': 1.5}], [{'index': 5, 'qty': 1}],
                      [{'index': 0, 'qty': 1}, {'index': 0, 'qty': 1}]):
            self.assert_error(400, '/api/returns', dict(base, items=items))
        self.assert_error(400, '/api/returns', dict(base, all=True, date='2026-10-18'))
        self.assert_error(400, '/api/returns', dict(base, all=True, date='2026-02-30'))
        self.assertEqual(self.get('/api/slips')[0]['returns'], [])

    def test_stale_or_repeated_returns_rejected(self):
        s = self.create()
        done = self.ret(s, all=True)
        self.assert_error(409, '/api/returns', {'id': s['id'], 'version': s['version'], 'date': '2026-10-20', 'all': True})
        self.assert_error(400, '/api/returns', {'id': done['id'], 'version': done['version'], 'date': '2026-10-20', 'all': True})
        self.assertEqual(len(self.get('/api/slips')[0]['returns']), 1)

    def test_concurrent_returns_do_not_double_count(self):
        s = self.create()
        data = {'id': s['id'], 'version': s['version'], 'date': '2026-10-20', 'all': True}
        def submit(_):
            try:
                self.post('/api/returns', data)
                return 200
            except urllib.error.HTTPError as e:
                return e.code
        with ThreadPoolExecutor(max_workers=2) as pool:
            outcomes = list(pool.map(submit, range(2)))
        self.assertEqual(sorted(outcomes), [200, 409])
        self.assertEqual(sum(i['returnedQty'] for i in self.get('/api/slips')[0]['items']), 4)

    def test_edit_changes_product_fields_and_preserves_receipt_links(self):
        s = self.ret(self.create(), items=[{'index':1,'qty':1}])
        stale = copy.deepcopy(s)
        s['items'][1].update(name='수정된 메인보드',serial='NEW-OUT',qty=2,productionMonth='2025-11',fault='수정 증상')
        changed = self.post('/api/slips',s)
        self.assertEqual(changed['items'][1]['name'],'수정된 메인보드')
        self.assertEqual(changed['items'][1]['serial'],'NEW-OUT')
        self.assertEqual(changed['items'][1]['returnedQty'],1)
        self.assert_error(409,'/api/slips',stale)
        changed['items'].reverse()
        reordered = self.post('/api/slips',changed)
        self.assertEqual(reordered['items'][1]['name'],'수정된 메인보드')
        self.assertEqual(reordered['returns'][0]['items'][0]['index'],1)
        reordered['returns']=[]
        reordered['note']='메모만 변경해도 기존 입고내역 유지'
        saved=self.post('/api/slips',reordered)
        self.assertEqual(saved['items'][1]['returnedQty'],1)
        self.assertEqual(saved['status'],'부분반환')

    def test_cannot_set_completed_in_editor(self):
        s = self.create()
        s['status'] = '반환완료'
        self.assert_error(400, '/api/slips', s)

    def test_legacy_completed_and_open_slips(self):
        old = self.create()
        for k in ('returns', 'version'):
            old.pop(k)
        old.update(status='반환완료', returned='2026-10-20', result='구버전 수리')
        with self.app.db() as c:
            c.execute('UPDATE slips SET body=? WHERE id=?', (json.dumps(old), old['id']))
        migrated = self.get('/api/slips')[0]
        self.assertEqual(migrated['status'], '반환완료')
        self.assertEqual(migrated['returns'][0]['date'], '2026-10-20')
        self.assertEqual(sum(i['returnedQty'] for i in migrated['items']), 4)
        old.update(status='발송', returned='')
        with self.app.db() as c:
            c.execute('UPDATE slips SET body=? WHERE id=?', (json.dumps(old), old['id']))
        self.assertEqual(self.get('/api/slips')[0]['returns'], [])

    def test_supplier_registration_edit_and_legacy_import(self):
        self.create()
        with self.app.db() as c:
            c.execute('DELETE FROM suppliers')
        imported = self.get('/api/suppliers')
        self.assertEqual(imported[0]['name'], '공급사 A')
        self.post('/api/suppliers', dict(imported[0], name='변경된 공급사', phone='010-1111-2222'))
        self.assertEqual([s['name'] for s in self.get('/api/suppliers')], ['변경된 공급사'])
        self.assertEqual(self.get('/api/slips')[0]['supplier'], '공급사 A')
        self.assert_error(400, '/api/suppliers', {'name': '변경된 공급사'})

    def test_supplier_delete_preserves_history_does_not_reseed_and_can_edit_old_slip(self):
        slip = self.create()
        slip['phone'] = '02-123-4567'
        slip = self.post('/api/slips', slip)
        supplier = self.get('/api/suppliers')[0]
        self.post('/api/suppliers/delete', supplier)
        self.assertEqual(self.get('/api/suppliers'), [])
        self.assertEqual(self.get('/api/suppliers'), [])
        saved = self.get('/api/slips')[0]
        self.assertEqual(saved['supplier'], '공급사 A')
        saved['note'] = '삭제된 받는이의 전표 수정'
        self.assertEqual(self.post('/api/slips', saved)['note'], saved['note'])
        self.assertEqual(self.get('/api/slips')[0]['phone'], slip.get('phone', ''))
        fresh = dict(slip); fresh.pop('id'); fresh.pop('number')
        self.assert_error(400, '/api/slips', fresh)
        self.assert_error(404, '/api/suppliers/delete', supplier)

    def test_supplier_delete_rejects_stale_details_and_invalid_id(self):
        supplier = self.get('/api/suppliers')[0]
        self.post('/api/suppliers', dict(supplier, phone='010-9999-1111'))
        self.assert_error(409, '/api/suppliers/delete', supplier)
        self.assertEqual(self.get('/api/suppliers')[0]['phone'], '010-9999-1111')
        for value in (True, 0, -1, str(supplier['id'])):
            self.assert_error(400, '/api/suppliers/delete', dict(supplier, id=value))

    def test_settings_and_excel_with_item_receipt_fields(self):
        self.assertIn('AS'.encode(), self.req('/'))
        self.post('/api/settings', {'company': '테스트 업체'})
        self.assertEqual(self.get('/api/settings')['company'], '테스트 업체')
        s = self.create()
        s = self.ret(s, items=[{'index': 0, 'qty': 1}], result='교환')
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            for name in z.namelist():
                ET.fromstring(z.read(name))
            sheet = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            rows = [[excel_text(c,ns) for c in row] for row in sheet.findall('s:sheetData/s:row', ns)]
            self.assertEqual(len(rows), 4)
            first, second = (dict(zip(rows[0], row)) for row in rows[1:3])
            self.assertEqual(first['출고 시리얼번호'], '001234')
            self.assertIsNone(first['입고 시리얼번호'])
            self.assertEqual(first['진행상태'], '부분완료')
            self.assertEqual(first['반환수량'], '1')
            self.assertEqual(first['미반환수량'], '1')
            self.assertEqual(first['입고처리'], '교환')
            self.assertEqual(first['입고일'], '2026-10-20')
            self.assertIsNone(second['입고처리'])
            self.assertIsNone(second['입고일'])
            self.assertNotIn('품명별 반환이력', rows[0])

    def test_products_registration_and_rename_preserves_old_slip(self):
        s = self.create()
        product = next(p for p in self.get('/api/products') if p['name'] == '메모리 DDR5')
        self.post('/api/products', dict(product, name='삼성 DDR5 16GB'))
        names = [p['name'] for p in self.get('/api/products')]
        self.assertIn('삼성 DDR5 16GB', names)
        self.assertNotIn('메모리 DDR5', names)
        self.assertEqual(self.get('/api/slips')[0]['items'][0]['name'], '메모리 DDR5')
        s['note'] = '기존 품명 유지'
        self.assertEqual(self.post('/api/slips', s)['items'][0]['name'], '메모리 DDR5')
        self.assert_error(400, '/api/products', {'name': '삼성 DDR5 16GB'})
        self.assert_error(400, '/api/products', {'name': ' '})
        self.assert_error(400, '/api/products', {'name': 'A' * 121})

    def test_legacy_model_is_combined_once_and_catalogue_is_seeded(self):
        s = self.ret(self.create(), items=[{'index': 0, 'qty': 1}])
        s['items'][0].update(name='메모리', model='DDR5')
        with self.app.db() as c:
            c.execute('UPDATE slips SET body=? WHERE id=?', (json.dumps(s), s['id']))
            c.execute('DELETE FROM products')
        migrated = self.get('/api/slips')[0]
        self.assertEqual(migrated['items'][0]['name'], '메모리 DDR5')
        self.assertNotIn('model', migrated['items'][0])
        self.assertEqual(migrated['items'][0]['returnedQty'], 1)
        self.assertIn('메모리 DDR5', [p['name'] for p in self.get('/api/products')])
        saved = self.post('/api/slips', migrated)
        self.assertEqual(saved['items'][0]['name'], '메모리 DDR5')
        self.assertEqual(saved['returns'], s['returns'])
        self.assertEqual(self.get('/api/slips')[0]['items'][0]['name'], '메모리 DDR5')

    def test_shipping_metadata_and_excel_preserve_tracking_zeros(self):
        s = self.create()
        s.update(shippedDate='2026-01-31', trackingNumber='000012345678', shippedMonth='틀린 월')
        saved = self.post('/api/slips', s)
        self.assertEqual(saved['shippedMonth'], '10월')
        self.assertEqual(saved['trackingNumber'], '000012345678')
        self.assertEqual(self.get('/api/slips')[0]['shippedDate'], '2026-01-31')
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            rows = [[excel_text(c,ns) for c in row] for row in root.findall('s:sheetData/s:row', ns)]
            exported = dict(zip(rows[0], rows[1]))
            self.assertEqual(exported['접수일 (출고일)'], '2026-10-19')
            self.assertEqual(exported['출고월'], '10월')
            self.assertNotIn('출고일',exported)
            self.assertEqual(exported['출고 송장번호'], '000012345678')
            self.assertEqual(exported['품명'], '메모리 DDR5')
            self.assertNotIn('모델명', exported)
            self.assertNotIn('받는이 전화번호', exported)
            self.assertNotIn('보낸이 전화번호', exported)
            self.assertEqual(rows[0][1:5], ['접수일 (출고일)','출고월','택배사','출고 송장번호'])
        saved.update(shippedDate='', trackingNumber='')
        cleared = self.post('/api/slips', saved)
        self.assertEqual(cleared['shippedMonth'], '10월')
        cleared['shippedDate'] = '2026-02-30'
        self.assert_error(400, '/api/slips', cleared)

    def test_removed_input_fields_are_not_accepted(self):
        self.post('/api/settings', {'company': '새 업체', 'companyPhone': '010-0000-0000',
                                    'address': '주소', 'business': '사업자번호'})
        settings = self.get('/api/settings')
        self.assertEqual(settings['companyPhone'], '010-0000-0000')
        self.assertNotIn('address', settings)
        self.assertNotIn('business', settings)
        self.assertNotIn('address', self.get('/api/suppliers')[0])
        s = self.create()
        s.update(address='새 주소', business='새 번호', supplierAddress='받는이 주소')
        saved = self.post('/api/slips', s)
        for key in ('address', 'business', 'supplierAddress'):
            self.assertNotIn(key, saved)

    def test_manual_product_name_survives_edit_return_and_excel(self):
        self.get('/api/products')
        s = self.create()
        manual = '수기 제품 <GPU> "미등록"'
        s['items'][1]['name'] = manual
        s = self.post('/api/slips', s)
        self.assertEqual(self.get('/api/slips')[0]['items'][1]['name'], manual)
        self.assertNotIn(manual, [p['name'] for p in self.get('/api/products')])
        s = self.ret(s, items=[{'index': 1, 'qty': 1}])
        self.assertEqual(s['items'][1]['name'], manual)
        self.assertEqual(s['items'][1]['returnedQty'], 1)
        s['note'] = '수기 품명 반환 이력 보존'
        self.assertEqual(self.post('/api/slips', s)['items'][1]['name'], manual)
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            self.assertIn(manual, [t.text for t in root.iter()])

    def test_manual_product_validation_still_rejects_empty_and_long_names(self):
        for name in ('', '   ', 'A' * 121):
            s = self.create()
            s['items'][0]['name'] = name
            self.assert_error(400, '/api/slips', s)

    def test_courier_requesters_production_month_and_excel(self):
        s = self.create()
        self.assertEqual(s['requesters'], [])
        self.assertEqual(s['courier'], '')
        self.assertEqual(s['items'][0]['productionMonth'], '')
        s.update(courier='CJ대한통운', requesters=['GN'])
        s['items'][0]['productionMonth'] = '2025-09'
        s = self.post('/api/slips', s)
        self.assertEqual(s['requesters'], ['GN'])
        self.assertEqual(s['items'][0]['productionMonth'], '2025-09')
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            ns = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            rows = [[excel_text(c,ns) for c in row] for row in root.findall('s:sheetData/s:row', ns)]
            record = dict(zip(rows[0], rows[1]))
            self.assertEqual(record['택배사'], 'CJ대한통운')
            self.assertEqual(record['의뢰업체'], 'GN')
            self.assertEqual(record['생산 년월'], '2025-09')
        s['requesters'] = []
        self.assertEqual(self.post('/api/slips', s)['requesters'], [])

    def test_invalid_requesters_and_production_month(self):
        s = self.create()
        for selection in (['기타'], ['GN', 'GN'], ['GN','대일'], 'GN'):
            bad = dict(s, requesters=selection)
            self.assert_error(400, '/api/slips', bad)
        for month in ('2025-13', '2025-01-01', '2025-1'):
            bad = copy.deepcopy(s)
            bad['items'][0]['productionMonth'] = month
            self.assert_error(400, '/api/slips', bad)

    def test_legacy_dual_requesters_are_preserved_until_explicit_choice(self):
        s = self.create()
        s['requesters'] = ['GN','대일']
        with self.app.db() as c:
            c.execute('UPDATE slips SET body=? WHERE id=?', (json.dumps(s),s['id']))
        old = self.get('/api/slips')[0]
        self.assertEqual(old['requesters'], ['GN','대일'])
        self.assert_error(400, '/api/slips', old)
        self.assertEqual(self.get('/api/slips')[0]['requesters'], ['GN','대일'])
        old['requesters'] = ['대일']
        self.assertEqual(self.post('/api/slips',old)['requesters'], ['대일'])

    def report_sample(self):
        def slip(number, sent, quantities, events, requester='GN'):
            return {'number':number,'date':sent,'supplier':'받는이 <A> & B','company':'내 업체','kind':'AS 발송',
                    'requesters':[requester],'status':'발송','items':[{'name':f'품목 {i}','qty':qty,'serial':f'000{i}'} for i,qty in enumerate(quantities)],
                    'returns':[{'date':when,'result':'수리','items':[{'index':i,'qty':qty} for i,qty in entries]} for when,entries in events]}
        records = [slip('R-001','2026-01-15',[6,4],[('2026-01-20',[(0,2)]),('2026-02-05',[(0,4),(1,1)]),('2026-03-01',[(1,3)])]),
                   slip('R-002','2026-02-10',[5],[('2026-02-20',[(0,2)])],'대일'),
                   slip('R-003','2026-03-25',[4],[]),
                   slip('R-004','2026-02-28',[1],[('2026-03-02',[(0,1)])])]
        return [self.app.normalize(r) for r in records]

    def test_report_months_partial_receipts_weighted_lead_time_and_backlog(self):
        from excel_report import analyse
        with patch.object(self.app,'korea_today',return_value=date(2026,3,31)):
            records = self.report_sample()
            report = analyse(records,date(2026,3,31))
        self.assertEqual(report['totals']['sent'],20)
        self.assertEqual(report['totals']['received'],13)
        self.assertEqual(report['totals']['pending'],7)
        self.assertEqual(report['totals']['complete'],2)
        self.assertEqual(report['totals']['partial'],1)
        self.assertEqual(report['totals']['days'],272)
        january, february, march = report['months']
        self.assertEqual(january, ['2026-01',1,10,2,8,5,0])
        self.assertEqual(february[:5], ['2026-02',2,6,7,7])
        self.assertAlmostEqual(february[5],125/7)
        self.assertEqual(march, ['2026-03',1,4,4,7,34.25,3])
        self.assertEqual(report['buckets'], [4,0,0,0,3])
        self.assertEqual(sum(entry[8] for entry in report['ledger']),13)
        for kind in ('받는이','의뢰업체'):
            self.assertEqual(sum(row[3] for row in report['groups'] if row[0]==kind),20)

    def test_report_workbook_charts_numeric_cells_and_relationships(self):
        import posixpath
        with patch.object(self.app,'korea_today',return_value=date(2026,3,31)):
            data = self.app.xlsx(self.report_sample())
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            for filename in z.namelist(): ET.fromstring(z.read(filename))
            book = ET.fromstring(z.read('xl/workbook.xml'))
            self.assertEqual([s.attrib['name'] for s in book.find('s:sheets',ns)],
                             ['AS 누적내역','입고처리목록','AS 보고서','월별 입출고','업체별 현황','입고 상세'])
            self.assertEqual(book.find('s:bookViews/s:workbookView',ns).attrib['activeTab'],'2')
            self.assertEqual(len([n for n in z.namelist() if n.startswith('xl/charts/chart')]),4)
            dashboard = ET.fromstring(z.read('xl/worksheets/sheet3.xml'))
            values = {c.attrib['r']:excel_text(c,ns) for c in dashboard.findall('.//s:c',ns)}
            self.assertEqual([values[cell] for cell in ('A7','D7','G7')],['20','13','7'])
            self.assertAlmostEqual(float(values['J7']),272/13)
            main = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            self.assertIsNotNone(main.find('.//s:c[@r="P2"]/s:v',ns))
            self.assertEqual(excel_text(main.find('.//s:c[@r="K2"]',ns),ns),'0000')
            for name in z.namelist():
                if not name.endswith('.rels'): continue
                base = posixpath.dirname(posixpath.dirname(name))
                for relation in ET.fromstring(z.read(name)):
                    target = posixpath.normpath(posixpath.join(base,relation.attrib['Target']))
                    self.assertIn(target,z.namelist())
            chart_ns = {'c':'http://schemas.openxmlformats.org/drawingml/2006/chart'}
            sheet_ids = {item.attrib['name']:item.attrib['sheetId'] for item in book.find('s:sheets',ns)}
            import re
            for filename in [n for n in z.namelist() if n.startswith('xl/charts/chart')]:
                chart = ET.fromstring(z.read(filename))
                for ref in chart.findall('.//c:strRef',chart_ns) + chart.findall('.//c:numRef',chart_ns):
                    formula = ref.find('c:f',chart_ns).text
                    match = re.fullmatch(r"'(.+)'!\$([A-Z]+)\$(\d+):\$([A-Z]+)\$(\d+)",formula)
                    self.assertIsNotNone(match)
                    source = ET.fromstring(z.read(f'xl/worksheets/sheet{sheet_ids[match[1]]}.xml'))
                    cache = {int(pt.attrib['idx']):pt.find('c:v',chart_ns).text for pt in ref.findall('.//c:pt',chart_ns)}
                    for offset,row in enumerate(range(int(match[3]),int(match[5])+1)):
                        value = excel_text(source.find(f'.//s:c[@r="{match[2]}{row}"]',ns),ns)
                        self.assertEqual(cache.get(offset),value)

    def test_report_empty_data_and_cross_year_months(self):
        from excel_report import analyse
        report = analyse([],date(2026,1,1))
        self.assertEqual(report['months'], [['2026-01',0,0,0,0,None,0]])
        with patch.object(self.app,'korea_today',return_value=date(2026,3,31)):
            records = self.report_sample()
            records[2]['date'] = '2025-12-25'
            report = analyse(records,date(2026,3,31))
            self.assertEqual([row[0] for row in report['months']],['2025-12','2026-01','2026-02','2026-03'])
            data = self.app.xlsx([])
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            self.assertEqual(len([n for n in z.namelist() if n.startswith('xl/charts/chart')]),4)
            self.assertNotIn('#DIV/0!',z.read('xl/worksheets/sheet3.xml').decode())

    def test_report_large_treatment_legend_keeps_all_quantities(self):
        with patch.object(self.app,'korea_today',return_value=date(2026,3,31)):
            record = self.report_sample()[0]
            record['items'] = [{'name':'메인보드','qty':12}]
            record['returns'] = [{'date':'2026-01-20','result':f'유형 {i}', 'items':[{'index':0,'qty':1}]} for i in range(12)]
            data = self.app.xlsx([self.app.normalize(record)])
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            ns = {'c':'http://schemas.openxmlformats.org/drawingml/2006/chart'}
            chart = ET.fromstring(z.read('xl/charts/chart4.xml'))
            values = [int(node.text) for node in chart.findall('.//c:numCache/c:pt/c:v',ns)]
            self.assertEqual(len(values),8)
            self.assertEqual(sum(values),12)

    def test_replacement_serials_preserve_outbound_and_partial_history(self):
        s = self.create()
        s = self.ret(s, items=[{'index': 0, 'qty': 1, 'receivedSerial': '000NEW-A'}])
        self.assertEqual(s['items'][0]['serial'], '001234')
        self.assertEqual(s['items'][0]['receivedSerial'], '000NEW-A')
        s = self.ret(s, items=[{'index': 0, 'qty': 1, 'receivedSerial': '000NEW-B'}])
        self.assertEqual(s['items'][0]['receivedSerial'], '000NEW-A\n000NEW-B')
        self.assertEqual(s['returns'][0]['items'][0]['receivedSerial'], '000NEW-A')
        s = self.ret(s, all=True)
        self.assertEqual(s['status'], '반환완료')
        s = self.post('/api/return-serials', {'id': s['id'], 'version': s['version'], 'eventIndex': 0,
                      'items': [{'index': 0, 'receivedSerial': '000CORRECTED'}]})
        self.assertEqual(s['items'][0]['receivedSerial'], '000CORRECTED\n000NEW-B')
        self.assertEqual(s['items'][0]['serial'], '001234')
        self.assertEqual(s['status'], '반환완료')
        self.assertEqual(s['returns'][0]['items'][0]['qty'], 1)
        self.assertEqual(s['returns'][0]['date'], '2026-10-20')
        self.assertEqual(self.get('/api/slips')[0]['items'][0]['receivedSerial'], '000CORRECTED\n000NEW-B')
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            xml = z.read('xl/worksheets/sheet1.xml').decode()
            self.assertIn('000CORRECTED', xml)
            self.assertIn('000NEW-B', xml)
            self.assertIn('001234', xml)

    def test_serial_corrections_validate_version_and_event_membership(self):
        s = self.ret(self.create(), items=[{'index': 1, 'qty': 1}])
        base = {'id': s['id'], 'version': s['version'], 'eventIndex': 0}
        for items in ([], [{'index': 0, 'receivedSerial': 'WRONG'}],
                      [{'index': 1, 'receivedSerial': 'A'}, {'index': 1, 'receivedSerial': 'B'}],
                      [{'index': 1, 'receivedSerial': 'A' * 401}]):
            self.assert_error(400, '/api/return-serials', dict(base, items=items))
        self.post('/api/return-serials', dict(base, items=[{'index': 1, 'receivedSerial': '000REPLACEMENT'}]))
        self.assert_error(409, '/api/return-serials', dict(base, items=[{'index': 1, 'receivedSerial': 'STALE'}]))
        self.assertEqual(self.get('/api/slips')[0]['items'][1]['receivedSerial'], '000REPLACEMENT')

    def test_daily_slip_numbers_and_issued_number_preservation(self):
        first, second = self.create(), self.create()
        self.assertEqual(first['number'], '261019-01')
        self.assertEqual(second['number'], '261019-02')
        self.assertEqual(self.create('2026-10-20')['number'], '261020-01')
        first['date'] = '2026-10-21'
        self.assertEqual(self.post('/api/slips', first)['number'], '261019-01')
        self.assertEqual(self.create()['number'], '261019-03')

    def test_concurrent_creations_have_distinct_daily_numbers(self):
        with ThreadPoolExecutor(max_workers=4) as pool:
            created = list(pool.map(lambda _: self.create(), range(4)))
        self.assertEqual(sorted(s['number'] for s in created), ['261019-01','261019-02','261019-03','261019-04'])

    def test_legacy_issued_number_is_kept_and_counted(self):
        s = self.create()
        s['number'] = 'AS-20261019-00001'
        with self.app.db() as c:
            c.execute('UPDATE slips SET body=? WHERE id=?', (json.dumps(s), s['id']))
        self.assertEqual(self.get('/api/slips')[0]['number'], 'AS-20261019-00001')
        self.assertEqual(self.create()['number'], '261019-02')

    def test_excel_order_and_dropdown_with_partial_item_receipt_dates(self):
        s = self.create()
        s = self.ret(s, items=[{'index': 0, 'qty': 1, 'receivedSerial': '000NEW'}], result='교환')
        s = self.ret(s, date='2026-10-21', items=[{'index': 1, 'qty': 1}], result='수리')
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            rows = [[excel_text(c,ns) for c in row] for row in root.findall('s:sheetData/s:row', ns)]
            headers = rows[0]
            self.assertEqual(headers[:5], ['전표번호','접수일 (출고일)','출고월','택배사','출고 송장번호'])
            out_index = headers.index('출고 시리얼번호')
            self.assertEqual(headers[out_index + 1], '입고 시리얼번호')
            self.assertEqual(headers[out_index + 2:out_index + 4], ['비고','M/B 수리내역서 작성'])
            self.assertEqual(headers[-2:], ['입고처리','입고일'])
            for forbidden in ('받는이 전화번호','보낸이 전화번호','품명별 반환이력','처리 결과','최근 반환일'):
                self.assertNotIn(forbidden, headers)
            first, second, pending = [dict(zip(headers, row)) for row in rows[1:]]
            self.assertEqual(first['입고 시리얼번호'], '000NEW')
            self.assertEqual(first['입고처리'], '교환')
            self.assertEqual(first['입고일'], '2026-10-20')
            self.assertIsNone(second['입고 시리얼번호'])
            self.assertEqual(second['입고처리'], '수리')
            self.assertEqual(second['입고일'], '2026-10-21')
            self.assertIsNone(pending['입고일'])
            validation = root.find('s:dataValidations/s:dataValidation', ns)
            self.assertEqual(validation.attrib['sqref'], 'X2:X4')
            self.assertEqual(validation.attrib['type'], 'list')
            self.assertEqual(validation.find('s:formula1', ns).text, 'ReceiptOptions')
            choices_sheet = ET.fromstring(z.read('xl/worksheets/sheet2.xml'))
            options = [t.text for t in choices_sheet.findall('.//s:t', ns)]
            self.assertEqual(options, self.get('/api/receipt-options'))
            self.assertIn('교환', options)

    def test_receipt_treatment_selection_and_history_correction(self):
        s = self.create()
        self.assert_error(400, '/api/returns', {'id':s['id'], 'version':s['version'], 'date':'2026-10-20', 'all':True, 'result':'임의 값'})
        s = self.ret(s, all=True, result='교환')
        s = self.post('/api/return-serials', {'id':s['id'], 'version':s['version'], 'eventIndex':0,
                      'result':'수리', 'items':[{'index':i, 'receivedSerial':''} for i in range(3)]})
        self.assertEqual(s['result'], '수리')
        self.assertEqual(s['items'][0]['receiptTreatment'], '수리')
        self.assertEqual(s['items'][0]['receivedDate'], '2026-10-20')
        self.assertEqual(s['status'], '반환완료')

    def test_per_item_notes_survive_returns_edits_search_and_excel(self):
        s = self.create()
        s['items'][0]['note'] = '=품목 비고 <메모>\n추가 확인'
        s['items'][1]['note'] = '별도 메모'
        s['note'] = '전표 전체 비고'
        s = self.post('/api/slips', s)
        s = self.ret(s, items=[{'index':0, 'qty':1, 'receivedSerial':'CHANGED-SERIAL'}])
        self.assertEqual(s['items'][0]['note'], '=품목 비고 <메모>\n추가 확인')
        s['items'].reverse()
        s = self.post('/api/slips', s)
        self.assertEqual(s['items'][2]['note'], '=품목 비고 <메모>\n추가 확인')
        result = self.get('/api/slips/page?view=all&field=details&q=' + urllib.parse.quote('추가 확인'))
        self.assertEqual(result['total'], 1)
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as archive:
            root = ET.fromstring(archive.read('xl/worksheets/sheet1.xml'))
            ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            rows = [[excel_text(cell, ns) for cell in row] for row in root.findall('s:sheetData/s:row', ns)]
            note = rows[0].index('비고')
            self.assertEqual(rows[3][note], '=품목 비고 <메모>\n추가 확인\n전표 전체 비고')
        s['items'][0]['note'] = 'x' * 501
        self.assert_error(400, '/api/slips', s)

    def test_per_item_repairs_remain_separate_through_history_reordering_and_export(self):
        s = self.create()
        s = self.ret(s, items=[{'index':0,'qty':1,'repairContent':'전원부 수리 A'},{'index':1,'qty':1,'repairContent':'팬 교체 B'}], mbRepairReport='공통 M/B 기록')
        self.assertEqual(s['items'][0]['repairContent'],'전원부 수리 A')
        self.assertEqual(s['items'][1]['repairContent'],'팬 교체 B')
        s = self.post('/api/return-serials',{'id':s['id'],'version':s['version'],'eventIndex':0,'items':[{'index':0,'receivedSerial':'','repairContent':'정정된 수리 A'},{'index':1,'receivedSerial':''}]})
        self.assertEqual(s['items'][0]['repairContent'],'정정된 수리 A')
        self.assertEqual(s['items'][1]['repairContent'],'팬 교체 B')
        s = self.ret(s, date='2026-10-21', items=[{'index':0,'qty':1,'repairContent':'추가 점검 A'},{'index':2,'qty':1,'repairContent':'정상 확인 C'}])
        s['receiptEdits'] = [{'index':2-entry['index'],'eventIndex':event_index,'date':event['date'],'result':event.get('result',''),'qty':entry['qty'],'receivedSerial':entry.get('receivedSerial',''),'mbRepairReport':event.get('mbRepairReport',''),'repairContent':entry.get('repairContent','')} for event_index,event in enumerate(s['returns']) for entry in event['items']]
        s['items'].reverse()
        s = self.post('/api/slips',s)
        self.assertEqual(len(s['returns']),2)
        self.assertEqual(s['items'][2]['repairContent'],'정정된 수리 A\n추가 점검 A')
        self.assertEqual(s['items'][1]['repairContent'],'팬 교체 B')
        self.assertEqual(s['items'][0]['repairContent'],'정상 확인 C')
        result = self.get('/api/slips/page?view=all&field=details&q='+urllib.parse.quote('정정된 수리'))
        self.assertEqual(result['total'],1)
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as archive:
            ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            for name in ('xl/worksheets/sheet1.xml','xl/worksheets/sheet6.xml'):
                rows=[[excel_text(cell,ns) for cell in row] for row in ET.fromstring(archive.read(name)).findall('s:sheetData/s:row',ns)]
                column=rows[0].index('처리내용(수리내용)')
                self.assertTrue(any('정정된 수리 A' in str(row[column]) for row in rows[1:]))

    def test_per_item_repair_validation_and_older_editor_preserve_content(self):
        s = self.create()
        for value in (123,'X'*2001):
            self.assert_error(400,'/api/returns',{'id':s['id'],'version':s['version'],'date':'2026-10-20','items':[{'index':0,'qty':1,'repairContent':value}]})
        s = self.ret(s, items=[{'index':0,'qty':1,'repairContent':'보존할 수리내용'}])
        s['note']='기존 API 수정'
        s=self.post('/api/slips',s)
        self.assertEqual(s['items'][0]['repairContent'],'보존할 수리내용')
        s['receiptEdits']=[{'index':0,'eventIndex':0,'date':'2026-10-20','qty':1,'result':'','receivedSerial':''}]
        s=self.post('/api/slips',s)
        self.assertEqual(s['items'][0]['repairContent'],'보존할 수리내용')
        s=self.post('/api/return-serials',{'id':s['id'],'version':s['version'],'eventIndex':0,'items':[{'index':0,'receivedSerial':'','repairContent':''}]})
        self.assertEqual(s['items'][0]['repairContent'],'')

    def test_mb_report_partial_full_returns_history_correction_and_excel(self):
        s = self.create()
        s['note'] = '=비고 <기록>\n둘째 줄'
        s = self.post('/api/slips', s)
        report = '전원부 <교체> & 점검\n부팅 정상'
        s = self.ret(s, items=[{'index':0,'qty':1},{'index':2,'qty':1}], mbRepairReport=report)
        self.assertEqual(s['items'][0]['mbRepairReport'], report)
        self.assertEqual(s['items'][2]['mbRepairReport'], report)
        self.assertEqual(s['items'][1]['mbRepairReport'], '')
        s = self.ret(s, items=[{'index':0,'qty':1}], mbRepairReport='추가 수리')
        self.assertEqual(s['items'][0]['mbRepairReport'], report+'\n추가 수리')
        s = self.ret(s, all=True)
        self.assertEqual(s['items'][0]['mbRepairReport'], report+'\n추가 수리')
        corrected = '=수정 내역 <확인>\n둘째 줄'
        s = self.post('/api/return-serials', {'id':s['id'],'version':s['version'],'eventIndex':0,
                      'mbRepairReport':corrected,'items':[{'index':0},{'index':2}]})
        self.assertEqual(s['items'][0]['mbRepairReport'], corrected+'\n추가 수리')
        self.assertEqual(s['items'][2]['mbRepairReport'], corrected)
        s = self.post('/api/slips', s)
        self.assertEqual(self.get('/api/slips')[0]['returns'], s['returns'])
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            rows = [[excel_text(c,ns) for c in row] for row in root.findall('s:sheetData/s:row',ns)]
            index = rows[0].index('입고 시리얼번호')
            self.assertEqual(rows[0][index:index+3], ['입고 시리얼번호','비고','M/B 수리내역서 작성'])
            first, second, third = [dict(zip(rows[0],row)) for row in rows[1:]]
            self.assertEqual(first['진행상태'], '완료')
            self.assertEqual(first['비고'], s['note'])
            self.assertEqual(first['M/B 수리내역서 작성'], corrected+'\n추가 수리')
            self.assertIsNone(second['M/B 수리내역서 작성'])
            self.assertEqual(third['M/B 수리내역서 작성'], corrected)
            self.assertEqual(root.findall('.//s:f',ns), [])

    def test_mb_report_editor_preserves_splits_and_clears_per_item(self):
        s = self.ret(self.create(),all=True,mbRepairReport='공통 수리내역')
        s['receiptEdits'] = [{'index':i,'eventIndex':0,'date':'2026-10-20','qty':int(item['qty']),'result':''}
                             for i,item in enumerate(s['items'])]
        s = self.post('/api/slips',s)
        self.assertEqual([i['mbRepairReport'] for i in s['items']], ['공통 수리내역']*3)
        s['receiptEdits'] = [{'index':i,'eventIndex':0,'date':'2026-10-20','qty':int(item['qty']),'result':'',
                             'mbRepairReport':['개별 수정','','공통 수리내역'][i]}
                            for i,item in enumerate(s['items'])]
        s = self.post('/api/slips',s)
        self.assertEqual([i['mbRepairReport'] for i in s['items']], ['개별 수정','','공통 수리내역'])
        self.assertEqual(s['status'],'반환완료')

    def test_mb_report_invalid_input_does_not_change_saved_records(self):
        s = self.create()
        for report in ('X'*2001, None, True, []):
            self.assert_error(400,'/api/returns', {'id':s['id'],'version':s['version'],'date':'2026-10-20',
                              'all':True,'mbRepairReport':report})
        self.assertEqual(self.get('/api/slips')[0]['returns'], [])
        s = self.ret(s,all=True,mbRepairReport='유지할 수리내역')
        self.assert_error(400,'/api/return-serials',{'id':s['id'],'version':s['version'],'eventIndex':0,
                          'mbRepairReport':'X'*2001,'items':[{'index':i} for i in range(3)]})
        self.assertEqual(self.get('/api/slips')[0]['items'][0]['mbRepairReport'],'유지할 수리내역')

    def test_custom_receipt_options_crud_preserves_history_and_empty_list(self):
        name = '유상 교환 완료'
        self.post('/api/receipt-options', {'name': name})
        row = next(x for x in self.get('/api/receipt-options/manage') if x['name'] == name)
        s = self.ret(self.create(), all=True, result=name)
        self.post('/api/receipt-options', dict(row, name='수리 후 출고'))
        choices = self.get('/api/receipt-options')
        self.assertIn('수리 후 출고', choices)
        self.assertNotIn(name, choices)
        self.assertEqual(self.get('/api/slips')[0]['result'], name)
        # Old values stay valid when saving the same historic record after renaming.
        s = self.post('/api/return-serials', {'id':s['id'], 'version':s['version'], 'eventIndex':0,
                      'items':[{'index':i,'receivedSerial':''} for i in range(3)]})
        self.assertEqual(s['result'], name)
        for option in self.get('/api/receipt-options/manage'):
            self.post('/api/receipt-options/delete', {'id':option['id']})
        self.assertEqual(self.get('/api/receipt-options'), [])
        self.assertEqual(self.get('/api/receipt-options/manage'), [])
        self.assertEqual(self.get('/api/slips')[0]['result'], name)
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            workbook = ET.fromstring(z.read('xl/workbook.xml'))
            self.assertIn('$A$1:$A$1', workbook.find('s:definedNames/s:definedName',ns).text)

    def test_receipt_options_validate_names_and_deleted_choices(self):
        for name in (' ', 'A'*61, '줄바꿈\n항목'):
            self.assert_error(400, '/api/receipt-options', {'name':name})
        self.assert_error(400, '/api/receipt-options', {'name':'수리'})
        self.assert_error(400, '/api/receipt-options/delete', {'id':999999})
        custom = '사용자 정의 항목'
        self.post('/api/receipt-options', {'name':custom})
        row = next(x for x in self.get('/api/receipt-options/manage') if x['name']==custom)
        self.post('/api/receipt-options/delete', {'id':row['id']})
        s = self.create()
        self.assert_error(400, '/api/returns', {'id':s['id'],'version':s['version'],'date':'2026-10-20','all':True,'result':custom})

    def test_excel_custom_option_list_supports_commas_and_over_255_characters(self):
        names = ['유상, 교환 "완료" & 확인'] + [f'사용자 정의 입고 항목 {i:02d}' for i in range(25)]
        for name in names:
            self.post('/api/receipt-options', {'name':name})
        self.create()
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            for filename in z.namelist():
                ET.fromstring(z.read(filename))
            sheet = ET.fromstring(z.read('xl/worksheets/sheet2.xml'))
            choices = [cell.text for cell in sheet.findall('.//s:t',ns)]
            self.assertEqual(choices, self.get('/api/receipt-options'))
            self.assertGreater(len(','.join(choices)),255)
            for name in names:
                self.assertIn(name, choices)
            workbook = ET.fromstring(z.read('xl/workbook.xml'))
            self.assertEqual(workbook.find('s:sheets',ns)[1].attrib['state'],'hidden')
            self.assertIn('$A$'+str(len(choices)), workbook.find('s:definedNames/s:definedName',ns).text)
            main = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            self.assertEqual(main.find('s:dataValidations/s:dataValidation/s:formula1',ns).text,'ReceiptOptions')

    def test_editor_can_change_completed_slip_and_receipt_fields(self):
        s=self.ret(self.create(),all=True,result='교환')
        s.update(number='CUSTOM-001',date='2026-10-18',company='수정 보낸이',companyPhone='010-9999-9999',manager='새 담당자',courier='로젠',trackingNumber='000UPDATED',requesters=['GN'])
        s['items'][0].update(name='수정 품명',serial='000CHANGED-OUT',productionMonth='2025-12',fault='수정 증상')
        s['receiptEdits']=[{'index':i,'eventIndex':0,'date':'2026-10-22','qty':int(item['qty']),'result':'수리','receivedSerial':f'000NEW-{i}'} for i,item in enumerate(s['items'])]
        saved=self.post('/api/slips',s)
        self.assertEqual(saved['number'],'CUSTOM-001')
        self.assertEqual(saved['date'],'2026-10-18')
        self.assertEqual(saved['shippedMonth'],'10월')
        self.assertEqual(saved['company'],'수정 보낸이')
        self.assertEqual(saved['items'][0]['serial'],'000CHANGED-OUT')
        self.assertEqual(saved['items'][0]['receivedSerial'],'000NEW-0')
        self.assertEqual(saved['items'][0]['receivedDate'],'2026-10-22')
        self.assertEqual(saved['result'],'수리')
        self.assertEqual(saved['status'],'반환완료')
        self.assertEqual(saved['elapsedDays'],4)

    def test_editor_can_reopen_add_delete_items_and_receipts(self):
        s=self.ret(self.create(),all=True)
        s['items'][0]['qty']=3
        s['status']='부분반환'
        s=self.post('/api/slips',s)
        self.assertEqual(s['items'][0]['remainingQty'],1)
        # Explicit receipt editing permits removing a product and its receipt rows.
        s['items']=s['items'][1:]
        s['receiptEdits']=[]
        s['status']='발송'
        s=self.post('/api/slips',s)
        self.assertEqual(len(s['items']),2)
        self.assertEqual(s['returns'],[])
        self.assertEqual(s['status'],'발송')
        s['items'].append({'name':'추가 제품','qty':1,'sourceIndex':None})
        s=self.post('/api/slips',s)
        self.assertEqual(len(s['items']),3)

    def test_editor_rejects_conflicting_receipt_quantities_dates_and_numbers(self):
        s=self.ret(self.create(),all=True)
        invalid=copy.deepcopy(s)
        invalid['items'][0]['qty']=1
        self.assert_error(400,'/api/slips',invalid)
        invalid=copy.deepcopy(s)
        invalid['date']='2026-10-21'
        self.assert_error(400,'/api/slips',invalid)
        other=self.create()
        s['number']=other['number']
        self.assert_error(400,'/api/slips',s)

    def test_elapsed_days_freezes_on_final_return_and_is_exported(self):
        s=self.create()
        with patch.object(self.app,'korea_today',return_value=date(2026,10,25)):
            self.assertEqual(self.get('/api/slips')[0]['elapsedDays'],6)
            s=self.ret(s,items=[{'index':0,'qty':1}],date='2026-10-20')
            self.assertEqual(s['elapsedDays'],6)
            s=self.ret(s,all=True,date='2026-10-23')
            self.assertEqual(s['elapsedDays'],4)
            self.assertEqual(self.get('/api/slips')[0]['elapsedDays'],4)
            with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
                root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
                rows=[[excel_text(cell,ns) for cell in row] for row in root.findall('s:sheetData/s:row',ns)]
                record=dict(zip(rows[0],rows[1]))
                self.assertEqual(record['경과일수'],'4')
                self.assertEqual(record['접수일 (출고일)'],'2026-10-19')
                self.assertEqual(rows[0][2],'출고월')

    def test_excel_elapsed_days_stop_for_fully_received_product(self):
        s=self.create()
        with patch.object(self.app,'korea_today',return_value=date(2026,10,25)):
            s=self.ret(s,items=[{'index':0,'qty':2}],date='2026-10-20')
            self.assertEqual(s['elapsedDays'],6)
            self.assertEqual(s['items'][0]['elapsedDays'],1)
            self.assertEqual(s['items'][1]['elapsedDays'],6)
            with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
                root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
                rows=[[excel_text(cell,ns) for cell in row] for row in root.findall('s:sheetData/s:row',ns)]
                self.assertEqual(dict(zip(rows[0],rows[1]))['경과일수'],'1')
                self.assertEqual(dict(zip(rows[0],rows[2]))['경과일수'],'6')

    def test_unknown_path_and_invalid_record(self):
        self.assert_error(400, '/api/slips', {'supplier': '', 'date': '2026-10-19'})
        with self.assertRaises(urllib.error.HTTPError) as err:
            self.req('/../app.py')
        self.assertEqual(err.exception.code, 404)

    def test_gn_qr_number_survives_edits_returns_and_excel(self):
        s = self.create()
        self.assertEqual(s['items'][0]['qrCodeNumber'], '')
        qr = '000QR-GN-001 <tag> & "number"'
        s['requesters'] = ['GN']
        s['items'][0]['qrCodeNumber'] = qr
        s = self.post('/api/slips', s)
        self.assertEqual(self.get('/api/slips')[0]['items'][0]['qrCodeNumber'], qr)
        s = self.ret(s, items=[{'index':0,'qty':1}])
        s = self.ret(s, all=True)
        self.assertEqual(s['items'][0]['qrCodeNumber'], qr)
        s['requesters'] = []
        s = self.post('/api/slips', s)
        self.assertEqual(s['items'][0]['qrCodeNumber'], qr)
        with zipfile.ZipFile(io.BytesIO(self.req('/api/export'))) as z:
            ns = {'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            rows = [[excel_text(cell,ns) for cell in row] for row in root.findall('s:sheetData/s:row',ns)]
            exported = dict(zip(rows[0], rows[1]))
            self.assertEqual(exported['QR코드번호'], qr)
            index = rows[0].index('입고 시리얼번호')
            self.assertEqual(rows[0][index:index+4], ['입고 시리얼번호','비고','M/B 수리내역서 작성','QR코드번호'])
            self.assertIsNone(dict(zip(rows[0],rows[2]))['QR코드번호'])

    def test_qr_number_validation_and_legacy_slips(self):
        s = self.create()
        for value in (None, True, [], 'Q'*501):
            invalid = copy.deepcopy(s)
            invalid['items'][0]['qrCodeNumber'] = value
            self.assert_error(400, '/api/slips', invalid)
        for item in s['items']:
            item.pop('qrCodeNumber')
        with self.app.db() as c:
            c.execute('UPDATE slips SET body=? WHERE id=?', (json.dumps(s),s['id']))
        self.assertEqual(self.get('/api/slips')[0]['items'][0]['qrCodeNumber'], '')

    def test_windows_browser_command_prefers_default_and_separate_window(self):
        url = 'http://127.0.0.1:8000'
        for program, name, flag in [('ChromeHTML','chrome.exe','--new-window'),
                                    ('FirefoxURL-123','firefox.exe','-new-window'),
                                    ('MSEdgeHTM','msedge.exe','--new-window')]:
            registry = SimpleNamespace(HKEY_CURRENT_USER='user',HKEY_LOCAL_MACHINE='machine')
            def open_key(root,path):
                if path.endswith('UserChoice') or path.endswith('App Paths\\'+name):
                    return nullcontext(path)
                raise OSError('Missing registry key')
            executable = 'C:\\Program Files\\Browser Folder\\' + name
            registry.OpenKey = open_key
            registry.QueryValueEx = lambda path,value: (program if value=='ProgId' else '"'+executable+'"', 1)
            with patch.dict('sys.modules', {'winreg':registry}), patch.dict(os.environ,{},clear=True), \
                 patch.object(self.app.os.path,'isfile',side_effect=lambda path:path==executable):
                self.assertEqual(self.app.windows_browser_command(url), [executable,flag,url])
        command = [executable,flag,url]
        with patch.object(self.app.sys,'platform','win32'), patch.object(self.app,'windows_browser_command',return_value=command), \
             patch.object(self.app.subprocess,'Popen') as launch, patch.object(self.app.webbrowser,'open') as default_open:
            self.app.open_program_window(url)
            launch.assert_called_once_with(command)
            default_open.assert_not_called()

    def test_launch_reuses_running_program_and_binds_before_opening_browser(self):
        self.assertTrue(self.app.existing_program(self.base))
        with patch.object(self.app,'ThreadingHTTPServer',side_effect=OSError('Address in use')), \
             patch.object(self.app,'existing_program',return_value=True), patch.object(self.app,'open_program_window') as open_window, \
             patch.object(self.app.sys,'argv',['app.py','--open-browser']), patch.dict(os.environ,{'PORT':'8000'}):
            self.app.main()
            open_window.assert_called_once_with('http://127.0.0.1:8000')
        events = []
        def bind_server(*args):
            events.append('bind')
            return SimpleNamespace(server_port=8123,serve_forever=lambda:events.append('serve'))
        with patch.object(self.app,'ThreadingHTTPServer',side_effect=bind_server), \
             patch.object(self.app,'open_program_window',side_effect=lambda url:events.append(url)), \
             patch.object(self.app.sys,'argv',['app.py','--open-browser']):
            self.app.main()
        self.assertEqual(events,['bind','http://127.0.0.1:8123','serve'])


if __name__ == '__main__':
    unittest.main()
