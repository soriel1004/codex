// Optional print regression check: Playwright, Chromium and Poppler utilities are required.
const {chromium} = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawn, execFileSync} = require('node:child_process');

(async () => {
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'as-print-test-'));
  const server = spawn(process.env.PYTHON_COMMAND || 'python3', ['-u', '-c',
    "import app; s=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler); print(s.server_port,flush=True); s.serve_forever()"],
    {cwd:path.resolve(__dirname,'..'), env:{...process.env, AS_DATA_DIR:temp}, stdio:['ignore','pipe','inherit']});
  let browser;
  try {
    const port = await new Promise((resolve,reject) => {
      let out = '';
      const timer = setTimeout(() => reject(Error('Server startup timed out')),10000);
      server.on('error', e => {clearTimeout(timer); reject(e);});
      server.on('exit', code => {clearTimeout(timer); reject(Error('Server exited: '+code));});
      server.stdout.on('data', chunk => {
        out += chunk;
        if (/^\d+\n/.test(out)) {clearTimeout(timer); resolve(Number(out.trim()));}
      });
    });
    browser = await chromium.launch({headless:true, ...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{})});
    const page = await browser.newPage({viewport:{width:1600,height:1100}});
    const errors=[]; page.on('pageerror',e=>errors.push(e.message));
    await page.goto(`http://127.0.0.1:${port}`);
    assert.equal(await page.locator('header a[href="/api/export"]').innerText(),'엑셀로 변환');
    assert.equal(await page.locator('[name=address],[name=business],[name=supplierAddress],[data-key=model]').count(),0);
    assert.equal(await page.locator('.heading h1').innerText(),'AS 업무');
    assert.ok(!(await page.locator('.heading').innerText()).includes('발송부터 반환까지'));
    await page.locator('#settingsBtn').click();
    await page.locator('#settingsForm [name=company]').fill('보낸 업체');
    await page.locator('#settingsForm [name=companyPhone]').fill('010-1111-2222');
    await page.getByRole('button',{name:'설정 저장',exact:true}).click();
    await page.locator('#suppliersBtn').click();
    await page.locator('#supplierForm [name=name]').fill('받는 업체');
    await page.locator('#supplierForm [name=phone]').fill('02-123-4567');
    await page.getByRole('button',{name:'받는이 저장',exact:true}).click();
    await page.locator('#supplierRows tr').filter({hasText:'받는 업체'}).waitFor();
    await page.locator('#supplierForm [name=name]').fill('추가 업체 ABC');
    await page.locator('#supplierForm [name=phone]').fill('010-9876-5432');
    await page.getByRole('button',{name:'받는이 저장',exact:true}).click();
    await page.locator('#supplierRows tr').filter({hasText:'추가 업체 ABC'}).waitFor();
    await page.locator('#supplierSearch').fill('abc');
    assert.equal(await page.locator('#supplierRows [data-supplier-edit]').count(),1);
    assert.match(await page.locator('#supplierRows').innerText(),/추가 업체 ABC/);
    await page.locator('#supplierSearch').fill('021234567');
    assert.equal(await page.locator('#supplierRows [data-supplier-edit]').count(),1);
    assert.match(await page.locator('#supplierRows').innerText(),/받는 업체/);
    await page.locator('#supplierRows [data-supplier-edit]').click();
    assert.equal(await page.locator('#supplierForm [name=name]').inputValue(),'받는 업체');
    await page.locator('#supplierSearch').fill('없는 업체');
    assert.match(await page.locator('#supplierRows').innerText(),/검색 결과가 없습니다/);
    await page.locator('#supplierSearch').fill('');
    assert.equal(await page.locator('#supplierRows [data-supplier-edit]').count(),2);
    await page.locator('[data-close=suppliers]').click();
    assert.match(await page.locator('#newBtn').innerText(),/전표 작성/);
    assert.ok(!(await page.locator('#newBtn').innerText()).includes('새 전표'));
    await page.locator('#newBtn').click();
    await page.locator('#editor').waitFor({state:'visible'});
    assert.equal(await page.locator('#editorTitle').innerText(),'전표 작성');
    assert.equal(await page.locator('#slipForm [name=status]').inputValue(),'발송');
    assert.equal(await page.locator('#editorNumberField').isVisible(),false);
    assert.equal(await page.locator('[name=requesters]:checked').count(),0);
    assert.equal(await page.locator('#items [data-key=qrCodeNumber]').isVisible(),false);
    await page.locator('#items [data-key=serial]').fill('NORMAL-SCAN');
    await page.locator('#items [data-key=serial]').press('Enter');
    assert.equal(await page.locator('#items [data-key=qty]').evaluate(el=>el===document.activeElement),true);
    await page.locator('[name=requesters][value=GN]').check();
    assert.equal(await page.locator('[name=requesters][value=대일]').isDisabled(),true);
    await page.locator('[name=requesters][value=GN]').uncheck();
    await page.locator('[name=requesters][value=대일]').check();
    assert.equal(await page.locator('[name=requesters][value=GN]').isDisabled(),true);
    await page.locator('[name=requesters][value=대일]').uncheck();
    await page.locator('[name=requesters][value=GN]').check();
    await page.locator('#slipForm [name=courier]').fill('CJ대한통운');
    await page.locator('#slipForm [name=date]').fill('2026-10-19');
    await page.locator('#slipForm [name=supplier]').selectOption({label:'받는 업체'});
    assert.equal(await page.locator('#slipForm [name=phone]').inputValue(),'02-123-4567');
    await page.locator('#receiptDate').fill('2026-12-31');
    assert.equal(await page.locator('#shippedMonth').innerText(),'12월');
    await page.locator('#receiptDate').fill('');
    assert.equal(await page.locator('#shippedMonth').innerText(),'—월');
    await page.locator('#receiptDate').fill('2026-10-19');
    assert.equal(await page.locator('#shippedMonth').innerText(),'10월');
    await page.locator('#slipForm [name=trackingNumber]').fill('0000123456789');
    await page.locator('#manageProducts').click();
    const productName='삼성 DDR5 <16GB> "메모리"';
    for (const name of [productName,'메인보드']) {
      await page.locator('#productForm [name=name]').fill(name);
      await page.getByRole('button',{name:'품명 저장',exact:true}).click();
      await page.locator('#productRows tr').filter({hasText:name}).waitFor();
    }
    await page.locator('#productSearch').fill('ddr5');
    assert.equal(await page.locator('#productRows [data-product-edit]').count(),1);
    assert.match(await page.locator('#productRows').innerText(),/DDR5/);
    await page.locator('#productRows [data-product-edit]').click();
    assert.equal(await page.locator('#productForm [name=name]').inputValue(),productName);
    await page.locator('#productSearch').fill('없는 품명');
    assert.match(await page.locator('#productRows').innerText(),/검색 결과가 없습니다/);
    await page.locator('#productSearch').fill('');
    assert.equal(await page.locator('#productRows [data-product-edit]').count(),2);
    await page.locator('[data-close=products]').click();
    assert.equal(await page.locator('#productNames option').count(),2);
    assert.equal(await page.locator('#items [data-key=name]').first().getAttribute('list'),'productNames');
    await page.locator('#items tr').first().locator('[data-key=name]').fill(productName);
    await page.locator('#items tr').first().locator('[data-key=serial]').fill('001234');
    const serialInput=page.locator('#items tr').first().locator('[data-key=serial]');
    const qrInput=page.locator('#items tr').first().locator('[data-key=qrCodeNumber]');
    const qtyInput=page.locator('#items tr').first().locator('[data-key=qty]');
    assert.equal(await serialInput.evaluate(el=>el.closest('td').nextElementSibling.querySelector('input').dataset.key),'qrCodeNumber');
    await serialInput.press('Enter');
    assert.equal(await qrInput.evaluate(el=>el===document.activeElement),true);
    const scannedQr='000QR-GN-001 <tag> & "number"';
    await qrInput.fill(scannedQr);
    await qrInput.press('Enter');
    assert.equal(await qtyInput.evaluate(el=>el===document.activeElement),true);
    await qtyInput.press('Enter');
    assert.equal(await page.locator('#editor').isVisible(),true);
    assert.deepEqual(await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json(),[]);
    await page.locator('[name=requesters][value=GN]').uncheck();
    assert.equal(await qrInput.isVisible(),false);
    assert.equal(await qrInput.inputValue(),scannedQr);
    await serialInput.fill('TAB-SCAN');
    await serialInput.press('Tab');
    assert.equal(await qtyInput.evaluate(el=>el===document.activeElement),true);
    await page.locator('[name=requesters][value=GN]').check();
    assert.equal(await qrInput.isVisible(),true);
    await serialInput.fill('001234');
    await serialInput.press('Tab');
    assert.equal(await qrInput.evaluate(el=>el===document.activeElement),true);
    await qrInput.fill(scannedQr+'TEMP');
    await qrInput.fill(scannedQr);
    await qrInput.press('Tab');
    assert.equal(await qtyInput.evaluate(el=>el===document.activeElement),true);
    // Some scanners send CR+LF; a second terminator must not skip the QR field.
    await serialInput.fill('001234TEMP');
    await serialInput.fill('001234');
    await serialInput.evaluate(el=>{
      el.focus();
      el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));
      document.activeElement.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));
    });
    assert.equal(await qrInput.evaluate(el=>el===document.activeElement),true);
    assert.equal(await page.locator('#items [data-key=productionMonth]').first().getAttribute('type'),'month');
    await page.locator('#items [data-key=productionMonth]').first().fill('2025-09');
    await page.locator('#items tr').first().locator('[data-key=qty]').fill('2');
    await page.locator('#items tr').first().locator('[data-key=note]').fill('품목별 관리 메모');
    assert.equal(await page.locator('#items [data-key=fault]').first().evaluate(el=>el.closest('td').nextElementSibling.querySelector('input').dataset.key),'note');
    await page.locator('#addItem').click();
    const manualName='수기 입력 GPU <임시 제품>';
    await page.locator('#items tr').last().locator('[data-key=name]').fill(manualName);
    await page.locator('#items tr').last().locator('[data-key=qrCodeNumber]').fill('000SECOND-QR');
    await page.locator('#items tr').last().locator('[data-key=qrCodeNumber]').press('Enter');
    assert.equal(await page.locator('#items tr').last().locator('[data-key=qty]').evaluate(el=>el===document.activeElement),true);
    assert.equal(await page.locator('#editor').isVisible(),true);
    await page.getByRole('button',{name:'전표 저장',exact:true}).click();
    await page.locator('#rows [data-return]').waitFor();
    assert.match(await page.locator('#rows').innerText(),/0000123456789/);
    assert.match(await page.locator('#rows strong').first().innerText(),/^261019-01$/);
    assert.equal(await page.locator('#rows .month-badge').count(),0);
    assert.equal(await page.locator('#rows [data-return]').innerText(),'부분완료');
    assert.equal(await page.locator('#rows [data-return-all]').innerText(),'완료');
    assert.equal(await page.locator('#rows .badge').innerText(),'발송');
    assert.deepEqual(await page.locator('.panel thead th').allTextContents(),['번호','받는이','구분','품명','송장번호','반환 / 발송','진행상태','경과일수','입고처리 / 입고일','관리']);
    const actionBoxes=await page.locator('#rows .row-actions button').evaluateAll(buttons=>buttons.map(b=>({top:b.getBoundingClientRect().top,left:b.getBoundingClientRect().left})));
    assert.equal(actionBoxes[0].top,actionBoxes[1].top);
    assert.equal(actionBoxes[2].top,actionBoxes[3].top);
    assert.ok(actionBoxes[2].top>actionBoxes[0].top);
    assert.equal(actionBoxes[0].left,actionBoxes[2].left);
    // Simulated saved slips exercise tracking without contacting any carrier.
    const trackingFixture=await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json();
    const trackingRoute=`http://127.0.0.1:${port}/api/slips`;
    const pageRoute=`http://127.0.0.1:${port}/api/slips/page?*`;
    async function listReady() { await page.locator('#slipList[aria-busy=false]').waitFor(); }
    // Presentation-only fixtures for carrier links and serial badges. Real indexed
    // search, paging and concurrent writes are tested against HTTP in test_storage.py.
    function fixturePage(route, records) {
      const p=new URL(route.request().url()).searchParams;
      const fold=v=>String(v||'').normalize('NFKC').toLowerCase();
      const compact=v=>v.replace(/[\s\p{Dash_Punctuation}\u2212]+/gu,'');
      const strings=v=>typeof v==='string'?[v]:v&&typeof v==='object'?Object.values(v).flatMap(strings):[];
      const statusLabel=v=>({'부분반환':'부분완료','반환완료':'완료'})[v]||v;
      const rows=records.filter(r=>{
        if(p.get('view')!=='all' && (r.status==='반환완료')!==(p.get('view')==='completed')) return false;
        if(p.get('status') && r.status!==p.get('status')) return false;
        if(p.get('requester') && (p.get('requester')==='none'?r.requesters.length:!r.requesters.includes(p.get('requester')))) return false;
        const fields={number:[r.number],supplier:[r.supplier],trackingNumber:[r.trackingNumber],name:r.items.map(i=>i.name),qrCodeNumber:r.items.map(i=>i.qrCodeNumber),
          outboundSerial:r.items.map(i=>i.serial).flatMap(v=>String(v||'').split(/[,，\r\n]+/)),
          receivedSerial:[...r.items.map(i=>i.receivedSerial),...r.returns.flatMap(e=>e.items.map(i=>i.receivedSerial))].flatMap(v=>String(v||'').split(/[,，\r\n]+/)),
          details:[r.note,r.result,...r.items.flatMap(i=>[i.fault,i.receiptTreatment,i.mbRepairReport]),...r.returns.flatMap(e=>[e.result,e.mbRepairReport])]};
        fields.serial=[...fields.outboundSerial,...fields.receivedSerial];
        fields.all=[...Object.values(fields).flat(),...strings({...r,items:r.items.map(i=>({...i,serial:'',receivedSerial:''})),returns:r.returns.map(e=>({...e,items:[]}))}),statusLabel(r.status)];
        const values=(fields[p.get('field')]||fields.all).map(fold);
        return fold(p.get('q')).trim().split(/\s+/).filter(Boolean).every(term=>values.some(value=>value.includes(term)||(compact(term)&&compact(value).includes(compact(term)))));
      });
      return route.fulfill({json:{rows,total:rows.length,page:1,pages:1,size:50,stats:{total:records.length,active:records.filter(r=>r.status!=='반환완료').length,completed:records.filter(r=>r.status==='반환완료').length,suppliers:2}}});
    }

    // Search all saved fields, including hidden later items and receipt history.
    // Distinct slips ensure a match in the wrong field cannot pass unnoticed.
    const searchBase=trackingFixture[0];
    const searchSlips=[
      {...searchBase, status:'부분반환', note:'전원 점검 요청',
        items:searchBase.items.map((item,i)=>({...item, serial:i?'SECOND-OUT-007':'AB-001 234', receivedSerial:i?'':'NEW-IN-0099\nEXTRA-IN-0010'})),
        returns:[{date:'2026-10-20',result:'교환 입고',mbRepairReport:'전원부 교체 후 정상',items:[{index:0,qty:1,receivedSerial:'HIST-IN-0008'}]}]},
      {...searchBase,id:9992,number:'261020-02',supplier:'다른 업체',phone:'010-5555-6666',requesters:['대일'],trackingNumber:'9988-7766',
        items:[{...searchBase.items[0],name:'테스트 GPU',serial:'AB-999999',qrCodeNumber:'ALT-QR-0002'}],returns:[]},
      {...searchBase,id:9993,number:'261001-03',supplier:'완료 업체',phone:'010-7777-8888',trackingNumber:'1122-3344',status:'반환완료',returned:'2026-10-21',requesters:[],
        items:[{...searchBase.items[0],name:'완료 메인보드',serial:'OLD-0001',qrCodeNumber:'COMPLETED-QR-0003',receivedSerial:'REPLACED-0002',returnedQty:2,remainingQty:0}],
        returns:[{date:'2026-10-21',result:'수리 입고',items:[{index:0,qty:2,receivedSerial:'REPLACED-0002'}]}]}
    ];
    await page.route(pageRoute,route=>fixturePage(route,searchSlips));
    await page.route(`http://127.0.0.1:${port}/api/slips/9993`,route=>route.fulfill({json:searchSlips[2]}));
    await page.reload();
    await page.locator('#rows [data-edit]').first().waitFor();
    async function checkSearch(field,query,numbers) {
      await page.locator('#searchField').selectOption(field);
      await listReady();
      await page.locator('#search').fill(query);
      await listReady();
      assert.deepEqual(await page.locator('#rows td:first-child strong').allTextContents(),numbers,`${field}: ${query}`);
      assert.equal(await page.locator('#count').innerText(),numbers.length+'건');
    }
    await page.locator('#statusFilter').selectOption('부분반환');
    await listReady();
    await checkSearch('receivedSerial','replaced0002',['261001-03']);
    assert.equal(await page.locator('[data-view=all]').getAttribute('class'),'active');
    assert.equal(await page.locator('#statusFilter').inputValue(),'');
    await page.locator('#rows [data-edit]').click();
    await page.locator('#editor').waitFor({state:'visible'});
    await page.locator('[data-close=editor]').last().click();
    assert.equal(await page.locator('[data-view=all]').getAttribute('class'),'active');
    assert.equal(await page.locator('#search').inputValue(),'replaced0002');
    await page.locator('[data-view=completed]').click();
    await listReady();
    await checkSearch('outboundSerial','secondout007',['261019-01']);
    assert.equal(await page.locator('[data-view=all]').getAttribute('class'),'active');
    for (const [field,query] of [
      ['all','ab001234'],['serial','ａｂ００１２３４'],['outboundSerial','secondout007'],
      ['receivedSerial','histin0008'],['receivedSerial','newin0099'],['receivedSerial','extrain0010'],['trackingNumber','0000-123 456789'],
      ['supplier','받는업체'],['name','임시 제품'],['qrCodeNumber','000secondqr'],['number','26101901'],
      ['details','전원부 교체'],['all','받는업체 gpu secondout007'],['all','교환입고'],['all','부분완료'],['all','021234567']
    ]) await checkSearch(field,query,['261019-01']);
    for (const [field,query] of [
      ['outboundSerial','newin0099'],['receivedSerial','ab001234'],['supplier','GPU'],
      ['qrCodeNumber','secondout007'],['all','받는업체 999999'],['all','trackingNumber'],
      ['all','sourceIndex'],['all','9992'],['all','::::'],['all','---'],['serial','0099extrain']
    ]) await checkSearch(field,query,[]);
    assert.equal(await page.locator('#empty h3').innerText(),'검색 결과가 없습니다');
    await checkSearch('all','   ',searchSlips.map(s=>s.number));
    await checkSearch('trackingNumber','99887766',['261020-02']);
    await checkSearch('all','ab001234',['261019-01']);
    await page.locator('#search').press('Enter');
    assert.equal(await page.locator('#editor').isVisible(),false);
    await page.locator('#requesterFilter').selectOption('대일');
    await listReady();
    assert.equal(await page.locator('#rows tr').count(),0);
    await page.locator('#statusFilter').selectOption('발송');
    await listReady();
    await page.locator('#resetSearch').click();
    await listReady();
    assert.equal(await page.locator('#searchField').inputValue(),'all');
    assert.equal(await page.locator('#requesterFilter').inputValue(),'');
    assert.equal(await page.locator('#statusFilter').inputValue(),'');
    assert.equal(await page.locator('#search').inputValue(),'');
    assert.equal(await page.locator('#rows tr').count(),3);
    await page.locator('#statusFilter').selectOption('부분반환');
    await listReady();
    await checkSearch('all','001234',['261019-01']);
    await page.locator('#resetSearch').click();
    await listReady();
    await page.locator('[data-view=active]').click();
    await listReady();
    await checkSearch('receivedSerial','replaced0002',['261001-03']);
    await page.locator('[data-view=completed]').click();
    await listReady();
    assert.deepEqual(await page.locator('#rows td:first-child strong').allTextContents(),['261001-03']);
    await page.locator('#resetSearch').click();
    await listReady();
    assert.equal(await page.locator('[data-view=completed]').getAttribute('class'),'active');
    assert.equal(await page.locator('#rows tr').count(),1);
    await checkSearch('all','   ',['261001-03']);
    assert.equal(await page.locator('[data-view=completed]').getAttribute('class'),'active');
    await page.locator('[data-view=all]').click();
    await listReady();
    await checkSearch('all','',searchSlips.map(s=>s.number));
    await page.setViewportSize({width:390,height:844});
    for (const selector of ['#searchField','#search','#resetSearch']) {
      const bounds=await page.locator(selector).boundingBox();
      assert.ok(bounds.x>=0 && bounds.x+bounds.width<=390,`${selector} fits narrow screens`);
    }
    await page.setViewportSize({width:1600,height:1100});
    await page.unroute(pageRoute);
    await page.reload(); await page.locator('#rows [data-edit]').waitFor();
    async function showTracking(courier, trackingNumber) {
      await page.unroute(pageRoute);
      await page.route(pageRoute,route=>fixturePage(route,[{...trackingFixture[0],courier,trackingNumber}]));
      await page.reload();
      await page.locator('#rows [data-edit]').waitFor();
    }
    await page.context().route('https://**/*',route=>route.fulfill({contentType:'text/html',body:'<title>배송 조회 테스트</title>'}));
    const carrierCases=[
      ['cj 대한통운','https://trace.cjlogistics.com/web/detail.jsp?slipno=0000123456789'],
      ['한진','https://www.hanjin.com/kor/CMS/DeliveryMgr/WaybillResult.do?mCode=MN038&wblnum=0000123456789'],
      ['롯데택배','https://www.lotteglogis.com/home/reservation/tracking/linkView?InvNo=0000123456789'],
      ['우체국','https://service.epost.go.kr/trace.RetrieveDomRigiTraceList.comm?sid1=0000123456789'],
      ['로젠','https://www.ilogen.com/web/personal/trace/0000123456789']
    ];
    for (const [carrier,url] of carrierCases) {
      await showTracking(carrier,'0000-123 456789');
      const link=page.locator('#rows a.tracking-link');
      assert.equal(await link.getAttribute('href'),url);
      assert.equal(await link.getAttribute('rel'),'noopener noreferrer');
      const popupReady=page.waitForEvent('popup');
      await link.click();
      const popup=await popupReady;
      await popup.waitForLoadState();
      assert.equal(popup.url(),url);
      assert.equal(await popup.evaluate(()=>window.opener),null);
      await popup.close();
    }
    for (const carrier of ['처음 보는 택배사','']) {
      await showTracking(carrier,'0000-123 456789');
      await page.locator('#rows [data-track]').click();
      assert.equal(await page.locator('#trackingNumber').inputValue(),'0000-123 456789');
      assert.equal(await page.locator('#trackingNumber').getAttribute('readonly'),'');
      assert.equal(await page.locator('#trackingOpen').isVisible(),false);
      await page.locator('#trackingCarrier').selectOption('한진택배');
      assert.equal(await page.locator('#trackingOpen').getAttribute('href'),carrierCases[1][1]);
      await page.locator('#trackingCarrier').selectOption('');
      assert.equal(await page.locator('#trackingOpen').getAttribute('href'),null);
      await page.locator('[data-close=trackingDialog]').last().click();
    }
    await showTracking('CJ대한통운','');
    assert.equal(await page.locator('#rows .tracking-link').isDisabled(),true);
    assert.match(await page.locator('#rows .tracking-link').innerText(),/송장번호 미등록/);
    await showTracking('CJ대한통운','0000123&other=456');
    assert.equal(await page.locator('#rows a.tracking-link').count(),0);
    await page.locator('#rows [data-track]').click();
    assert.match(await page.locator('#toast').innerText(),/전표 수정에서 확인/);
    assert.equal(await page.locator('#trackingDialog').isVisible(),false);
    await page.unroute(pageRoute);
    await page.reload(); await page.locator('#rows [data-edit]').waitFor();
    const trackingUnchanged=await (await page.request.get(trackingRoute)).json();
    assert.equal(trackingUnchanged[0].courier,'CJ대한통운');
    assert.equal(trackingUnchanged[0].trackingNumber,'0000123456789');
    await page.locator('#requesterFilter').selectOption('none');
    await listReady();
    assert.equal(await page.locator('#rows [data-edit]').count(),0);
    await page.locator('#requesterFilter').selectOption('GN');
    await listReady();
    assert.equal(await page.locator('#rows [data-edit]').count(),1);
    await page.locator('#requesterFilter').selectOption('대일');
    await listReady();
    assert.equal(await page.locator('#rows [data-edit]').count(),0);
    await page.reload(); await page.locator('#rows [data-edit]').click();
    await page.locator('#editor').waitFor({state:'visible'});
    assert.equal(await page.locator('#receiptDate').inputValue(),'2026-10-19');
    assert.equal(await page.locator('[name=requesters]:checked').count(),1);
    assert.equal(await page.locator('#slipForm [name=courier]').inputValue(),'CJ대한통운');
    assert.equal(await page.locator('#items [data-key=productionMonth]').first().inputValue(),'2025-09');
    assert.equal(await page.locator('#items [data-key=note]').first().inputValue(),'품목별 관리 메모');
    assert.equal(await page.locator('#items [data-key=qrCodeNumber]').first().inputValue(),scannedQr);
    assert.equal(await page.locator('#items [data-key=qrCodeNumber]').last().inputValue(),'000SECOND-QR');
    assert.equal(await page.locator('#shippedMonth').innerText(),'10월');
    assert.equal(await page.locator('#items tr').first().locator('[data-key=name]').inputValue(),productName);
    assert.equal(await page.locator('#items tr').last().locator('[data-key=name]').inputValue(),manualName);
    await page.locator('#receiptDate').fill('2026-10-18');
    await page.getByRole('button',{name:'전표 저장',exact:true}).click();
    await page.locator('#rows td:first-child small').filter({hasText:'2026-10-18'}).waitFor();
    await page.locator('#rows [data-return]').click();
    await page.locator('#returnDialog').waitFor({state:'visible'});
    assert.equal(await page.locator('#returnItems tr').first().locator('textarea').isEnabled(),true);
    assert.equal(await page.locator('#returnForm [name=result]').evaluate(el=>el.tagName),'SELECT');
    const atBottom = await page.locator('#receiptFields').evaluate(el => el.previousElementSibling.id === 'returnHistory' && el.nextElementSibling.classList.contains('modal-footer'));
    assert.ok(atBottom,'receipt treatment controls must be at the bottom above Save');
    await page.locator('#manageReceiptOptions').click();
    const customTreatment='유상, 교환 "완료"';
    await page.locator('#receiptOptionForm [name=name]').fill(customTreatment);
    await page.getByRole('button',{name:'항목 저장',exact:true}).click();
    await page.locator('#receiptOptionRows tr').filter({hasText:customTreatment}).waitFor();
    await page.locator('#receiptOptionForm [name=name]').fill('삭제용 임시 항목');
    await page.getByRole('button',{name:'항목 저장',exact:true}).click();
    const temporary = page.locator('#receiptOptionRows tr').filter({hasText:'삭제용 임시 항목'});
    await temporary.waitFor(); await temporary.locator('[data-receipt-option-delete]').click();
    await page.waitForResponse(r=>r.url().endsWith('/api/receipt-options/manage'));
    assert.equal(await page.locator('#receiptOptionRows tr').filter({hasText:'삭제용 임시 항목'}).count(),0);
    await page.locator('[data-close=receiptOptionsManager]').click();
    await page.locator('#returnForm [name=result]').selectOption(customTreatment);
    await page.locator('#returnItems tr').first().locator('textarea').fill('000NEW-A');
    const repairReport='전원부 <교체> & 점검\n부팅 정상';
    await page.locator('#returnForm [name=mbRepairReport]').fill(repairReport);
    assert.equal(await page.locator('#returnItems tr').first().locator('[type=checkbox]').isChecked(),true);
    await page.locator('#returnItems tr').first().locator('[type=number]').fill('1');
    await page.locator('#returnForm [name=date]').fill('2026-10-20');
    await page.locator('#returnSave').click();
    await page.locator('#rows .badge').filter({hasText:'부분완료'}).waitFor();
    assert.equal(await page.locator('#rows .serial-changes').count(),0);
    await page.locator('#search').fill('부분완료');
    await listReady();
    assert.equal(await page.locator('#rows [data-edit]').count(),1);
    await page.locator('#search').fill('');
    await listReady();
    await page.locator('#statusFilter').selectOption({label:'부분완료'});
    await listReady();
    assert.equal(await page.locator('#rows [data-edit]').count(),1);
    await page.locator('#statusFilter').selectOption('');
    await listReady();
    const partialData = await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json();
    assert.equal(partialData[0].returns[0].result, customTreatment);
    assert.equal(partialData[0].items[0].mbRepairReport,repairReport);
    assert.equal(partialData[0].items[1].mbRepairReport,'');
    await page.locator('#rows [data-edit]').click();
    await page.locator('#editor').waitFor({state:'visible'});
    assert.equal(await page.locator('#items tr').first().locator('[data-key=name]').getAttribute('readonly'),null);
    await page.locator('#slipForm [name=note]').fill('부분반환 이력 유지');
    await page.getByRole('button',{name:'전표 저장',exact:true}).click();
    await page.locator('#rows [data-return-all]').waitFor();
    await page.locator('#rows [data-print]').click();
    assert.equal(await page.locator('#paper .slip').count(),2);
    const proof=await page.locator('#paper').innerText();
    assert.ok(proof.includes(productName));
    assert.ok(proof.includes(manualName));
    assert.ok(proof.includes('001234'));
    assert.ok(proof.includes('접수일 (출고일) 2026-10-18'));
    assert.ok(!proof.includes('CJ대한통운'));
    assert.ok(proof.includes('받는이 보관용')&&proof.includes('보낸이 보관용'));
    assert.deepEqual(await page.locator('#paper .print-table').first().locator('th').allTextContents(),['품명','출고 시리얼번호','수량','불량 증상']);
    for (const hidden of ['2026-02-28','출고 월','0000123456789','송장번호','모델명','사업자','주소','생산 년월','입고 시리얼번호','입고처리','입고일','2025-09','000NEW-A',customTreatment,repairReport,'M/B 수리내역서','비고','부분반환 이력 유지','품목별 관리 메모',scannedQr,'000SECOND-QR','QR코드번호']) assert.ok(!proof.includes(hidden));
    await page.pdf({path:path.join(temp,'workflow.pdf'),preferCSSPageSize:true});
    const text=execFileSync('pdftotext',['-raw',path.join(temp,'workflow.pdf'),'-'],{encoding:'utf8'});
    assert.ok(!text.includes('0000123456789')&&!text.includes('2026-02-28'));
    assert.ok(text.includes('02-123-4567')&&text.includes('010-1111-2222'));
    await page.locator('[data-close=preview]').click();
    // Existing receipt information can still be corrected while a slip is in progress.
    await page.locator('#rows [data-return]').click();
    await page.locator('#returnDialog').waitFor({state:'visible'});
    assert.equal(await page.locator('.serial-history').count(),1);
    const lastField = await page.locator('.serial-history').first().locator('[data-history-result]').evaluate(el => Boolean(el.closest('.serial-history').lastElementChild.contains(el)));
    assert.ok(lastField, 'history treatment selector must follow serial fields');
    await page.locator('.serial-history').first().locator('[data-history-index]').fill('000CORRECTED');
    assert.equal(await page.locator('.serial-history [data-history-report]').inputValue(),repairReport);
    await page.locator('.serial-history [data-history-report]').fill('정정 수리내역');
    await page.locator('.serial-history').first().locator('[data-history-result]').selectOption('정상 판정');
    await Promise.all([
      page.waitForResponse(r=>r.url().includes('/api/slips/page?')),
      page.locator('.serial-history').first().locator('[data-save-serials]').click()
    ]);
    await listReady();
    const receiptData=await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json();
    assert.equal(receiptData[0].returns[0].result,'정상 판정');
    assert.equal(receiptData[0].items[0].mbRepairReport,'정정 수리내역');
    await page.locator('[data-close=returnDialog]').last().click();
    await page.locator('#rows [data-return-all]').click();
    await page.locator('#returnDialog').waitFor({state:'visible'});
    assert.match(await page.locator('#returnTitle').innerText(),/완료 처리/);
    assert.equal(await page.locator('#returnItems [type=checkbox]:checked').count(),2);
    assert.equal(await page.locator('#returnSave').innerText(),'완료 저장');
    let current=await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json();
    assert.equal(current[0].status,'부분반환');
    assert.equal(current[0].returns.length,1);
    await page.locator('[data-close=returnDialog]').last().click();
    current=await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json();
    assert.equal(current[0].returns.length,1);
    await page.locator('#search').fill('26101901');
    await listReady();
    await page.locator('#rows [data-return-all]').click();
    await page.locator('#returnDialog').waitFor({state:'visible'});
    await page.setViewportSize({width:390,height:844});
    const incoming=page.locator('#returnItems tr').first().locator('textarea');
    await incoming.scrollIntoViewIfNeeded();
    const rect=await incoming.boundingBox();
    assert.ok(rect.x>=0&&rect.x+rect.width<=390,'incoming serial must fit the visible phone width');
    await incoming.fill('000FULL-A');
    await page.locator('#returnItems tr').last().locator('textarea').fill('000FULL-B');
    assert.equal(await page.locator('#returnForm [name=mbRepairReport]').inputValue(),'');
    await page.locator('#returnForm [name=mbRepairReport]').fill('전량 수리내역');
    await page.locator('#returnForm [name=date]').fill('2026-10-20');
    assert.ok((await page.locator('#returnForm [name=result] option').allTextContents()).includes(customTreatment));
    await page.locator('#returnForm [name=result]').selectOption('수리');
    await page.locator('#returnSave').click();
    await page.setViewportSize({width:1600,height:1100});
    await page.locator('#rows .badge').filter({hasText:/^완료$/}).waitFor();
    assert.equal(await page.locator('[data-view=all]').getAttribute('class'),'active');
    assert.equal(await page.locator('#search').inputValue(),'26101901');
    await page.locator('#search').fill('');
    await listReady();
    await page.locator('[data-view=completed]').click();
    await listReady();
    await page.locator('#rows .badge').filter({hasText:'완료'}).waitFor();
    assert.equal(await page.locator('#rows .serial-changes').count(),0);
    assert.ok(!(await page.locator('#rows').innerText()).includes('시리얼 변경'));
    assert.equal(await page.locator('#rows [data-return],#rows [data-return-all]').count(),0);
    assert.equal(await page.locator('#rows .tracking-link').count(),0);
    assert.deepEqual(await page.locator('#rows .row-actions button').allTextContents(),['수정','전표 출력','삭제']);
    await page.locator('#rows [data-edit]').click();
    await page.locator('#editor').waitFor({state:'visible'});
    assert.equal(await page.locator('#slipForm [name=status] option:checked').innerText(),'완료');
    const summaries = page.locator('#editorReceiptSerialRows .editor-receipt-row');
    assert.equal(await summaries.count(),2);
    assert.equal(await summaries.first().locator('[data-receipt-field=mbRepairReport]').first().inputValue(),'정정 수리내역');
    assert.equal(await summaries.first().locator('[data-receipt-field=mbRepairReport]').last().inputValue(),'전량 수리내역');
    assert.equal(await page.locator('#items tr').first().locator('[data-key=serial]').inputValue(),'001234');
    assert.equal(await summaries.first().locator('[data-receipt-field=receivedSerial]').first().inputValue(),'000CORRECTED');
    assert.equal(await summaries.first().locator('[data-receipt-field=receivedSerial]').last().inputValue(),'000FULL-A');
    assert.equal(await summaries.last().locator('[data-receipt-field=receivedSerial]').inputValue(),'000FULL-B');
    assert.equal(await summaries.first().locator('[data-receipt-field=receivedSerial]').first().getAttribute('readonly'),null);
    assert.equal(await summaries.first().locator('[data-receipt-field=receivedSerial]').first().evaluate(el=>getComputedStyle(el).resize),'none');
    assert.equal(await summaries.first().locator('[data-receipt-field=receivedSerial]').first().evaluate(el=>el.getBoundingClientRect().height),84);
    const beforeEdit = await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json();
    await page.locator('#slipForm [name=note]').fill('완료 전표 수정 후 입고 시리얼 유지');
    await page.getByRole('button',{name:'전표 저장',exact:true}).click();
    await page.locator('#rows [data-edit]').waitFor();
    const afterEdit = await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json();
    assert.deepEqual(afterEdit[0].returns,beforeEdit[0].returns);
    assert.equal(afterEdit[0].items[0].receivedSerial,'000CORRECTED\n000FULL-A');
    await page.locator('#rows [data-edit]').click();
    await page.locator('#editor').waitFor({state:'visible'});
    await page.locator('#slipForm [name=number]').fill('261019-99');
    await page.locator('#slipForm [name=company]').fill('수정 보낸이');
    await page.locator('#slipForm [name=companyPhone]').fill('010-7777-8888');
    await page.locator('#receiptDate').fill('2026-10-17');
    await page.locator('#items tr').first().locator('[data-key=name]').fill('수정 품명');
    await page.locator('#items tr').first().locator('[data-key=serial]').fill('OUT-EDIT');
    await page.locator('#items tr').first().locator('[data-key=qrCodeNumber]').fill('000EDITED-QR');
    await page.locator('#items tr').first().locator('[data-key=productionMonth]').fill('2025-10');
    await page.locator('#items tr').first().locator('[data-key=qty]').fill('3');
    const firstEntry = page.locator('.editor-receipt-row').first().locator('.editor-receipt-entry').first();
    await firstEntry.locator('[data-receipt-field=receivedSerial]').fill('EDITED-NEW');
    await firstEntry.locator('[data-receipt-field=mbRepairReport]').fill('수정 수리내역');
    await firstEntry.locator('[data-receipt-field=date]').fill('2026-10-20');
    await firstEntry.locator('[data-receipt-field=qty]').fill('2');
    await firstEntry.locator('[data-receipt-field=result]').selectOption('수리');
    assert.equal(await page.locator('#slipForm [name=status]').inputValue(),'반환완료');
    await page.locator('#addItem').click();
    assert.equal(await page.locator('#items tr').count(),3);
    await page.locator('#items tr').last().locator('.remove').click();
    assert.equal(await page.locator('#items tr').count(),2);
    assert.equal(await page.locator('#slipForm [name=status]').inputValue(),'반환완료');
    await page.getByRole('button',{name:'전표 저장',exact:true}).click();
    await page.locator('#rows [data-edit]').waitFor();
    const fullyEdited=await (await page.request.get(`http://127.0.0.1:${port}/api/slips`)).json();
    assert.equal(fullyEdited[0].number,'261019-99');
    assert.equal(fullyEdited[0].company,'수정 보낸이');
    assert.equal(fullyEdited[0].items[0].name,'수정 품명');
    assert.equal(fullyEdited[0].items[0].serial,'OUT-EDIT');
    assert.equal(fullyEdited[0].items[0].qrCodeNumber,'000EDITED-QR');
    assert.equal(fullyEdited[0].items[0].receivedSerial,'EDITED-NEW\n000FULL-A');
    assert.equal(fullyEdited[0].elapsedDays,3);
    assert.equal(fullyEdited[0].items[0].mbRepairReport,'수정 수리내역\n전량 수리내역');
    assert.equal(await page.locator('#rows .serial-changes').count(),0);
    await page.locator('#rows [data-print]').click();
    assert.ok(!(await page.locator('#paper').innerText()).includes('EDITED-NEW'));
    assert.match(await page.locator('#paper').innerText(),/OUT-EDIT/);
    await page.locator('[data-close=preview]').click();
    // Completed-list comparison handles unchanged batches, missing numbers,
    // changes on later items, and HTML-like serial text without changing records.
    const serialCases=[
      {items:[{serial:'OLD-1, OLD-2',receivedSerial:' OLD-2\nOLD-1\nOLD-1 '},{serial:'000123',receivedSerial:''}],count:0},
      {items:[{serial:'',receivedSerial:'NEW-ONLY'},{serial:'SAME',receivedSerial:' SAME '}],count:0},
      {items:[{serial:'OLD-1, OLD-2',receivedSerial:'OLD-2\nOLD-1'},{name:'교환 <img src=x onerror=alert(1)>',serial:'000123',receivedSerial:'000124<NEW>'}],count:1},
      {items:[{serial:'OLD-1',receivedSerial:'NEW-1'},{serial:'OLD-2',receivedSerial:'NEW-2'}],count:2}
    ];
    for (const scenario of serialCases) {
      const fixture={...fullyEdited[0],items:fullyEdited[0].items.map((item,index)=>({...item,...scenario.items[index]}))};
      await page.route(pageRoute,route=>fixturePage(route,[fixture]));
      await page.reload();
      await page.locator('[data-view=completed]').click();
      await listReady();
      await page.locator('#rows [data-edit]').waitFor();
      assert.equal(await page.locator('#rows .serial-changes').count(),0);
      await page.locator('[data-view=all]').click();
      await listReady();
      assert.equal(await page.locator('#rows .serial-changes').count(),0);
      await page.unroute(pageRoute);
    }
    await page.reload();
    await page.locator('#newBtn').click();
    await page.locator('#editor').waitFor({state:'visible'});
    assert.equal(await page.locator('#slipForm [name=status]').inputValue(),'발송');
    assert.equal(await page.locator('[name=requesters]:checked').count(),0);
    assert.equal(await page.locator('#items [data-key=qrCodeNumber]').isVisible(),false);
    assert.equal(await page.locator('#items [data-key=qrCodeNumber]').inputValue(),'');
    assert.equal(await page.locator('#editorReceiptSerials').isVisible(),false);
    await page.locator('[data-close=editor]').first().click();
    await page.locator('[data-view=completed]').click();
    await listReady();
    await page.locator('#rows [data-delete]').click();
    await page.locator('#deleteDialog').waitFor({state:'visible'});
    assert.equal(await page.locator('#deleteSlipNumber').innerText(),'261019-99');
    assert.ok((await page.locator('#deleteSlipDetails').innerText()).includes('받는 업체'));
    assert.equal(await page.locator('#deleteCancel').evaluate(el=>el===document.activeElement),true);
    await page.locator('#deleteCancel').click();
    assert.equal((await (await page.request.get(trackingRoute)).json()).length,1);
    await page.locator('#rows [data-delete]').click();
    await page.locator('#deleteDialog').waitFor({state:'visible'});
    await page.locator('#deleteConfirm').click();
    await page.locator('#deleteDialog').waitFor({state:'hidden'});
    await page.waitForFunction(()=>document.querySelector('#count').textContent==='0건');
    assert.deepEqual(await (await page.request.get(trackingRoute)).json(),[]);
    const deletedExport=await (await page.request.get(`http://127.0.0.1:${port}/api/export`)).body();
    fs.writeFileSync(path.join(temp,'deleted.xlsx'),deletedExport);
    const deletedXml=execFileSync('python3',['-c',"import zipfile,sys;print(zipfile.ZipFile(sys.argv[1]).read('xl/worksheets/sheet1.xml').decode())",path.join(temp,'deleted.xlsx')],{encoding:'utf8'});
    assert.ok(!deletedXml.includes('261019-99'));
    await page.locator('[data-view=active]').click();
    await listReady();
    await page.locator('#newBtn').click();
    await page.locator('#editor').waitFor({state:'visible'});
    await page.locator('#slipForm [name=supplier]').selectOption({label:'받는 업체'});
    await page.locator('#items [data-key=name]').first().fill('삭제 확인용 품목');
    await page.getByRole('button',{name:'전표 저장',exact:true}).click();
    await page.locator('#rows [data-delete]').waitFor();
    await page.locator('#rows [data-delete]').click();
    await page.locator('#deleteDialog').waitFor({state:'visible'});
    await page.keyboard.press('Escape');
    await page.locator('#deleteDialog').waitFor({state:'hidden'});
    assert.equal((await (await page.request.get(trackingRoute)).json()).length,1);
    await page.locator('#rows [data-delete]').click();
    await page.locator('#deleteDialog').waitFor({state:'visible'});
    await page.locator('#deleteConfirm').click();
    await page.waitForFunction(()=>document.querySelector('#count').textContent==='0건');
    assert.deepEqual(await (await page.request.get(trackingRoute)).json(),[]);
    assert.deepEqual(errors,[]);
    console.log('PASS: field-specific and combined search, normalized identifiers, later items and receipt history, filters/reset and narrow screens; active/completed deletion, cancellation and Excel exclusion; removed serial change indicators with serial data preserved; per-item notes retained and excluded from print; five-carrier tracking, completed-slip editing, returns, elapsed days and print.');
  } finally {
    if(browser) await browser.close();
    server.kill();
    if (process.env.KEEP_PRINT_ARTIFACTS) console.log('Print artifacts:',temp);
    else fs.rmSync(temp,{recursive:true,force:true});
  }
})().catch(e=>{console.error(e);process.exitCode=1;});
